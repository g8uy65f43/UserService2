
const express = require('express')
const app = express()
const port = 3000

app.get('/', (req, res) => {
  res.send('Hello World!')
})
   const mongoose = require('mongoose');
    console.log("3")

    mongoose.connect('mongodb+srv://g8uy65f43:Ewdsa8819@cluster0.ltyxo62.mongodb.net/?retryWrites=true&w=majority');
    console.log("2")

    const Cat = mongoose.model('TakeOutQR', { name: String });
    console.log(Cat)
    const kitty = new Cat({ name: 'TakeOutQR' });
    kitty.save().then(() => console.log('meow'));





app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})
