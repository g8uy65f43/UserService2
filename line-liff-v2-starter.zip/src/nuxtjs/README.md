# LIFF Starter NuxtJS

LIFF Starter is a good starter template can help you understand how to integrate LIFF into your own development environment.

You can check the source code and modify it to implement some cool stuff with LIFF API.

## Build Setup

```bash
# install dependencies
$ npm install

# serve with hot reload at localhost:3000
$ npm run dev

# build for production and launch server
$ npm run build
$ npm run start

# generate static project
$ npm run generate
```
