# LIFF Starter

LIFF Starter is a good starter template can help you understand how to integrate LIFF into your own development environment.

You can check the source code and modify it to implement some cool stuff with LIFF API.

## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
```
